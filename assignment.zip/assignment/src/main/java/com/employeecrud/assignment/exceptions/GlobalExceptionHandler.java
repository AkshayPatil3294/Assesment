package com.employeecrud.assignment.exceptions;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {

 @ExceptionHandler(value = {IllegalArgumentException.class, IllegalStateException.class})
 protected ResponseEntity<Object> handleConflict(
         RuntimeException ex, WebRequest request) {
     String bodyOfResponse = "This should be application specific";
     return handleExceptionInternal(ex, bodyOfResponse,
             new HttpHeaders(), HttpStatus.CONFLICT, request);
 }

 @ExceptionHandler(value = {EmployeeNotFoundException.class})
 protected ResponseEntity<Object> handleEmployeeNotFoundException(
         EmployeeNotFoundException ex, WebRequest request) {
     String bodyOfResponse = ex.getMessage();
     return handleExceptionInternal(ex, bodyOfResponse,
             new HttpHeaders(), HttpStatus.NOT_FOUND, request);
 }

 @ExceptionHandler(value = {DepartmentNotFoundException.class})
 protected ResponseEntity<Object> handleDepartmentNotFoundException(
         DepartmentNotFoundException ex, WebRequest request) {
     String bodyOfResponse = ex.getMessage();
     return handleExceptionInternal(ex, bodyOfResponse,
             new HttpHeaders(), HttpStatus.NOT_FOUND, request);
 }

 @ExceptionHandler(value = {CustomErrorException.class})
 protected ResponseEntity<Object> handleCustomErrorException(
         CustomErrorException ex, WebRequest request) {
     String bodyOfResponse = ex.getData().toString();
     return handleExceptionInternal(ex, bodyOfResponse,
             new HttpHeaders(), ex.getStatus(), request);
 }
}